@extends('layouts.app')

@section('titulo', 'formulario')

@section('contenido')
    <h1></h1>

@endsection