

<?php $__env->startSection('titulo', 'formulario'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>hola mundo</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practica-formulario\resources\views/formulario.blade.php ENDPATH**/ ?>